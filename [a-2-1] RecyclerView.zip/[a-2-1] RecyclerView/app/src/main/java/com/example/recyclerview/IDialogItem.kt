package com.example.recyclerview

interface IDialogItem {
    fun addItem(item: ItemModel)
}