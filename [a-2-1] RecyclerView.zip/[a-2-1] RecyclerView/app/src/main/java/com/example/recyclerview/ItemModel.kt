package com.example.recyclerview

data class ItemModel (
    val item: String,
    val detalhe: String,
    var detailVisibility: Boolean
)