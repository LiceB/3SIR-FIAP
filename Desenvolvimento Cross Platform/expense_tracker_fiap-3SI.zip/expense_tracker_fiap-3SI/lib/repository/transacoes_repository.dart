import 'package:expense_tracker/models/conta.dart';
import 'package:flutter/material.dart';
import 'package:ionicons/ionicons.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../models/categoria.dart';
import '../models/tipo_transacao.dart';
import '../models/transacao.dart';

class TransacoesReepository {
  Future<List<Transacao>> listarTransacoes(
      {TipoTransacao? tipoTransacao}) async {
    await Future.delayed(const Duration(seconds: 5));
    final supabase = Supabase.instance;
    final rows = await supabase.client
        .from('transacoes')
        .select<List<Map<String, dynamic>>>();

    final transacaoes = rows.map((row) => Transacao(
        id: row['id'],
        descricao: row['descricao'],
        tipoTransacao: TipoTransacao.values[row['tipo_transacao']],
        valor: row['valor'],
        data: row['data'],
        categoria: row['categorias']['categoria_id'],
        conta: row['contas']['conta_id']
        )).toList();

        return transacaoes;
  }
}
