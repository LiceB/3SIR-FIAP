import 'package:expense_tracker/models/banco.dart';
import 'package:flutter/material.dart';

class BancoSelect extends StatelessWidget {
  final Banco? banco;
  final void Function()? onTap;
  const BancoSelect({super.key, this.banco, this.onTap});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: banco == null
          ? CircleAvatar()
          : CircleAvatar(
              backgroundImage: AssetImage('images/${banco?.logo}'),
            ),
    );
  }
}
