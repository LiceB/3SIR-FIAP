enum TipoTransacao { receita, despesa }
